package com.example.yogeshwari_1nt18is188_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText n1= findViewById(R.id.num1);
        EditText n2= findViewById(R.id.num2);
        TextView t= findViewById(R.id.res);
        Button bt= findViewById(R.id.bt);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1= Integer.parseInt(n1.getText().toString());
                int num2= Integer.parseInt(n2.getText().toString());
                String res= String.valueOf(num1+num2);
                Intent it = new Intent(getApplicationContext(),second.class);
                it.putExtra("sum",res);
                startActivity(it);
              t.setText("Result is: "+res);
            }
        });
    }



}

